The Off By One Browser - Obligatory ReadMe.txt
==============================================

Nothing to it, really.  The file ob1.exe is the complete Off By One 
Browser application (NOT a Setup kit), just run it.  Online Help is 
available.

SSL support is provided through the OpenSSL DLL files SSLeay32.dll and 
libeay32.dll.  They are not required if you don't need SSL support.

http://www.OffByOne.com


