Pablo Commander
 
For years my favourite file manager was Norton Commander. It was fast and easy to use and could do almost anything. 
Unfortunately they never continued their development to catch up with the latest technologies like shell integration and a modern look and feel. 
This application is a mixture between Norton Commander and Windows Explorer. 
I've tried using as much of the standard Windows Shell functionality as possible (so I didn't have to duplicate it myself).

Key features:
Most features of the orginal Norton Commander like copy, move, delete and dual pane views.
Look and feel of Windows Explorer.
Drag and drop support.
Multi threaded file management by using shell API for most operations.
Changes to file and folders from another programs will immediately reflected in the views of Pablo Commander.
Context menus just like Windows Explorer.
Compare to contents of two folder.
Intergrated FTP client (including FTP to FTP), view/open files and folder just like your local files/folders.
Intelligent addressbar to select folders, execute programs, connect to ftp sites and almost every other Windows Shell action.

Keyboard Shortcuts:
F2		-	Rename file/folder
F3		-	View selected file/folder
F4		-	Edit selected file/folder
F5		-	Copy selected file/folder
F6		-	Move/Rename selected file/folder
F7		- 	Create new folder
F8		-	Delete selected file/folder
F9		-	Reserved
F10		-	Exit application

Ctrl+A		-	Select all files/folders
Numpad +	-	Select group
Numpad -	-	Deselect group
Numpad *	-	Invert selection

Alt+Enter	-	Show properties of selected file/folder
Ctrl+F		-	Find files
Ctrl+U		-	Swap panels
Ctrl+D		-	Set focus to addressbar

Tab		-	Switch focus between left-right panel.
Ctrl+R		- 	Refresh active panel
Alt+F1		-	Select drive for Left panel
Alt+F2		-	Select drive for Right panel
Ctrl+F1		-	Select FTP site for Left panel
Ctrl+F2		-	Select FTP site for Right panel

Ctrl+C		_	Copy selected file/folder to clipboard
Ctrl+Ins	_	Copy selected file/folder to clipboard
Ctrl+V		_	Paste selected file/folder from clipboard
Shift+Ins	_	Paste selected file/folder from clipboard
Ctrl+X		-	Copy selected file/folder to clipboard and delete original
Del		-	Delete selected file/folder


� Copyright 2005 Pablo Software Solutions
http://www.pablosoftwaresolutions.com