static char RCSid[] =
"$Header: d:/cvsroot/tads/TADS2/DUMMY.C,v 1.2 1999/05/17 02:52:11 MJRoberts Exp $";

/* Copyright (c) 1992, 2002 Michael J. Roberts.  All Rights Reserved. */
/*
Name
  dummy.c - TEMPORARY dummy file for resolving symbols
Function
  Resolves certain symbols while linking with old tads 1.x output layer
Notes
  should be removed as soon as new output layer is written
Modified
  02/16/92 MJRoberts     - creation
*/

#include <stdio.h>
#include "os.h"

int tadsdebug;
int biexcnt;
int biextab;
int dbgactive;

