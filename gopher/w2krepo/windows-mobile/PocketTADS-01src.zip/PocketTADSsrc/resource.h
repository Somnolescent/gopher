//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by pGlulxe.rc
//
#define IDS_APP_TITLE                   1
#define IDS_HELLO                       2
#define IDC_PGLULXE                     3
#define IDI_PGLULXE                     101
#define IDM_MENU                        102
#define IDD_ABOUTBOX                    103
#define IDS_HELP                        104
#define IDD_MENU                        104
#define IDD_STYLES                      105
#define IDD_COLOR                       106
#define IDD_GRAPHICS                    107
#define IDB_MENU                        111
#define IDS_COMMAND1                    301
#define IDC_STYLE                       1001
#define IDC_TOADD                       1001
#define IDC_WINDOW                      1002
#define IDC_MENULIST                    1002
#define IDC_FONT                        1003
#define ID_ADD                          1003
#define ID_DELETE                       1004
#define IDC_IMAGES                      1005
#define IDC_BOLD                        1006
#define IDC_SCALE                       1006
#define IDC_ITALIC                      1007
#define IDC_SAMPLE                      1008
#define IDC_FORE                        1009
#define IDC_BACK                        1010
#define IDC_SPINRED                     1010
#define IDC_RED                         1011
#define IDC_CLEARTYPE                   1011
#define IDC_SPINGREEN                   1012
#define IDC_GREEN                       1013
#define IDC_SPINBLUE                    1014
#define IDC_BLUE                        1015
#define IDC_CHOSEN                      1016
#define IDC_FONTSIZE                    1017
#define IDC_FIXED                       1018
#define IDM_MAIN_COMMAND1               40001
#define IDM_HELP_ABOUT                  40003
#define IDM_FILES                       40004
#define IDS_CAP_FILES                   40005
#define ID_OPENSTORY                    40006
#define ID_EXIT                         40007
#define IDM_OPTIONS                     40008
#define IDS_CAP_OPTIONS                 40009
#define ID_COLORS                       40010
#define ID_MOVES                        40010
#define ID_STYLES                       40011
#define IDM_HELP                        40012
#define IDS_CAP_HELP                    40013
#define ID_ABOUT                        40014
#define ID_ACTIONS                      40015
#define IDM_MOVE                        40017
#define IDS_CAP_MOVE                    40019
#define IDM_ACTION                      40020
#define IDS_CAP_ACTION                  40022
#define ID_SAVE                         40023
#define ID_RESTORE                      40024
#define ID_SCRIPT                       40025
#define ID_RECORD                       40026
#define ID_REPLAY                       40027
#define ID_BUTTON40036                  40036
#define ID_BUTTON40037                  40037
#define IDS_CAP_MENUITEM40038           40039
#define ID_BUTTON40041                  40041
#define ID_MORE                         40042
#define ID_GRAPHICS                     40043
#define ID_REFRESH                      40044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40045
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
