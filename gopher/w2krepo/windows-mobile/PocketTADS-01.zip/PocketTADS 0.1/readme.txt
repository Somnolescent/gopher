PocketTADS 0.1
==============

Ported by David Batterham <drbatter@progsoc.org>
based on
PocketGlk 0.1 by Stark Springs
GlkTADS by Stephen Granade
Glk by Andrew Plotkin
TADS 2.7 by Michael J. Roberts

PocketTADS is a port of the TADS Runtime to PocketPC (aka Windows CE 3). TADS (Text Adventure Development System) is a runtime and development environment for interactive fiction (aka text adventures). See http://www.tads.org/ for more info on TADS.

Very little of the PocketTADS code was written by me. My task in porting this software was mainly to glue together various existing libraries and programs (see list of libraries above).

If you have other PocketGlk applications (eg. PocketGlulxe), your PocketTADS preferences will likely be applied in those applications as well (and vice versa). This is a feature, not a bug :)

INSTALLATION
------------
Simply copy the executable for your processor (ARM, MIPS or SH3) into "/Program Files" or "/Windows/Start Menu/Programs". If you don't know what processor you have, look in Start -> Settings -> System -> About.

WARNING
-------
This is alpha-release software. It's unlikely to melt your PocketPC, but things happen. Your use of PocketTADS is entirely at your own risk.

FUTURE PROJECTS
---------------
Future projects for me or others:
- Backport PocketGlk to WinCE 2.x so users of older WinCE devices don't have to miss out
- Port a zcode interpreter to PocketGlk, to play zcode games with the ClearType feature I've added