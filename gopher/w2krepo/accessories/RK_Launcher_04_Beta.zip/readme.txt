RK Launcher 0.4 Beta build 151

Requirements

    OS: Windows 2000/XP
        Please use 16 bits (65536 colors) of screen color depth or higher.

    Note: This software does not work in Windows 95/98/Me/NT.

Copyright

    The author (RaduKing) owns the full copyright to RK Launcher.

    I choose to allow the use, reproduction, and distribution of this software 
    in a free manner, but only under the assumption that the contents of this 
    archive are not changed or altered in any way, and it's contents are intact.
    (for any sort of reproduction please ask for permission from me first)

    Default Icon set created by Philipp Antoni
    Visit http://pantoni.icadex.com/ for Icons, Themes, Wallpapers and more

    You are not allowed to distribute the included icons in any modified
    form or without RK Launcher

    The author assumes no responsibility, or gives any sort of guarantees for
    damages that may occur from using this software.

Download:

    http://home.cogeco.ca/~raduking

Contact:

    rklauncher@gmail.com

Note:

    since this is a nightly build some of the features may not work or are disabled

What's new in version 0.4 Beta:

RKLauncher.exe

- themes and backgrounds changed completely
- added exclusions for apps/windows
- cannot drag excluded apps to dock
- Y'z Docklet support improved
- icons from any folder (added Browse button)
- browse for application in dock item properties
- hide label
- label transparency
- saves changes on windows restart
- saves items on change
- fixed wrong appearance of OD docklet in add docklets dlg
- fixed save on change for add docklet
- changed 'application' to 'docklet_yz' or 'docklet_od' in itemlist.conf
- added Hide Taskbar option
- added Hotspot for dock showing up when the mouse goes to margin
- added Import Y'z Dock background
- settings are saved when the Settings dialog closes
- fixed DockletSetImageFile not setting the right image
- added Hide Indicators
- added Hide Poofs
- ObjectDock Docklet support improved (still missing some features)
- added DockletSetIndicator(HWND, BOOL) that's missing in OD Docklet SDK
- docklet settings are saved via OnSave in itemlist.conf
- added effect when a new item is shown in dock
- RK Launcher can go up to 200fps now
- opened applications now receive focus
- *.ico files added to icon browse dialog
- messenger windows jump on attention when minimized to dock
- excluded items moved to 'excluded.conf' file
- detection of fullscreen windows

YzDocklet.dll

- fixed YzDockletGetFolderPath unicode result
- fixed YzDockletGetRect giving client coords instead of screen coords
- fixed YzDockletGetInt not returning the default value (Tasks docklet)
- changed icon loading
- fixed some docklets not letting RK Launcher close
- no Y'z Docklet API can be called after RK Launcher is closing
