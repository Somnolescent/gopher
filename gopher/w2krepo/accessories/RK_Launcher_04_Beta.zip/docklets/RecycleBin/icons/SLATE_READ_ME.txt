Slate � 2002-2003 by Marvilla

Rules and regulations and all that good stuff concerning my icons:
These icons are copyrighted by me. They are for personal use only.
You may not distribute, re-zip, re-bundle or upload these icons anywhere without my prior permission. You may not sell them or use them for profit in any way. You may not use them on any website or place them for download anywhere in the public domain. Do not take credit for creating my icons. If you have any questions regarding any of my icons please email me.
Permission was given to M. Yamaguchi to use 9 icons from the full set of 25 Slate icons for this release of Y'z Dock. If you would like to download the whole Slate set visit my Iconica website here: http://www.marvilla.us 
Use these icons on your computer at your own risk, I take no responsibility for anything that may occur to your property after you choose to use my icons or Y'z Dock.

And last but not least...enjoy! :)

Marvilla
iconica@marvilla.us
http://www.marvilla.us
http://www.designtechnika.com
http://marvilla.freeplace.net

