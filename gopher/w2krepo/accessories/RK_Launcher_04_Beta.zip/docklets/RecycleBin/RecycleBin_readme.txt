-------------------------------------------------------------------------------

  RecycleBin Docklet v0.4.1 for Y'z Dock v0.8.0+
  by Haitham Al-Beik (Org: M.Yamaguchi)            Sunday, January 25th, 2004
  www.dockex.com
  
-------------------------------------------------------------------------------

Revision History
----------------
 v0.4.1 (01-25-2004)
  + Dropping CD/DVD-ROM drive(s) will eject the drive(s)

 v0.4.0
  + Last update by M.Yamaguchi for this docklet


ReadMe First
------------
Added support to eject drives by dragging them to the docklet.
In addition, multiple drives can be dragged at once to eject them all at once.


Installation
------------
  1. Exract the archive file inside your Yz Docklets folder 

  2. Right click the dock and select "Add Doclet..." 

  3. Highlight "RecycleBin" and click on "Add to Dock" 


Comments/Suggestions/Problems
-----------------------------
Please email me at albeik@dockex.com! 


Terms of Use
------------
You can reproduce, change and distribute any files in this site, without 
permission as long as this file is included unchanged. 
No liability for the contents of any of the files can be accepted. Use the 
concepts, examples and other content at your own risk. Additionally, this is a 
beta version, possibly with many inaccuracies or errors. And please take into 
consideration that there may be specification change in the future. 

By downloading this docklet you agree to be bound to the terms of use described
at http://www.dockex.com/?pageId=disclaimer.

-------------------------------------------------------------------------------

  http://www.dockex.com/
  Copyright � 2004 Haitham Al-Beik <albeik@dockex.com> 

-------------------------------------------------------------------------------