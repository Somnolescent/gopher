Xnews - a free 32 bit newsreader for Win9x/NT

(C)opyright 1998-99 by Luu Tran.
http://xnews.3dnews.net

See manual.html for complete documenation.

Installation Guide:

There's no install program. Just unzip to some directory then run
Xnews.exe. If you are upgrading, just unzip and overwrite
everything.

The first time you run Xnews, it will bring up the Setup dialog.
Enter your name, etc. I'll only describe the unfamiliar items
here.


Public Email

This is the email you want to put in your From: header when
posting to usenet. In contrast. Email is the email you want to to
use when replying via private email.
Why use separate emails for usenet and mail? I do it to help deal
with spam.

IDToken

This is a string Xnews embeds in Message-ID in order to track
your posts and alert you to replies to your articles. You can use
any string of letters and numbers. I use my email without the @
and . luutrangeocitiescom. The idea is to use a string that noone
else is likely to use.

Once you've done that, click Okay. Xnews will ask you to create a
server profile. (The program can deal with multiple servers.)
Enter the server name, e.g., news.mindspring.com. Then enter an
alias or title for the server, e.g., Mindspring. The alias is
what will appear on the menu.

That's it. You should now say yes when it asks if you want to
retrieve the newsgroup list. Kick back and enjoy.
