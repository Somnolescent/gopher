package Net::FTP::L;

require Net::FTP::I;

@ISA = qw(Net::FTP::I);

1;
