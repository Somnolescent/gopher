
Sitescooper README	(version 2.3.0beta)


Sitescooper automatically retrieves the stories from several news websites,
trims off extraneous HTML, and converts them into formats you can read on your
Palm computing device for later reading on-the-move. It maintains a cache, and
will avoid stories you've already read. It can handle 1-page sites, 1-page with
diffing, 2-level and 3-level sites, and it's very easy to add a new site to its
list. Even if you don't have a Palm handheld, it's still handy for simple
website-to-text conversion. 

The documentation, including installation instructions, is available in HTML
form in the "doc" subdirectory. If you're reading this with a web browser,
click <a href=doc/index.html>here</a> (or <a href=index.html>here</a> if you've
installed using the RPM).

It's also available online at the following URL:

	http://sitescooper.org/doc/
	<a href=http://sitescooper.org/doc/>(link)</a>

If you're looking for more details on how to install or run sitescooper, follow
those links.


LICENSING

Sitescooper is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

Included in the distribution is a copy of Algorithm::Diff, an implementation of
the Longest Common Subsequence algorithm, Copyright 1998, 1999 M-J. Dominus
(mjd-perl-diff /at/ plover.com). It is free software; you can redistribute it
and/or modify it under the same terms as Perl itself.

This program, and the remaining files included with it, is distributed in the
hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.  The General Public License is
included as the file "doc/gpl.html" in this distribution, or online at:

	http://sitescooper.org/doc/gpl.html
	<a href=http://sitescooper.org/doc/gpl.html>(link)</a>

