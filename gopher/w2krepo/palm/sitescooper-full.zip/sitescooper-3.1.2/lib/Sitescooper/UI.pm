#===========================================================================

package Sitescooper::UI;

require Exporter;
use Carp;

@ISA = qw(Exporter);
@EXPORT= qw();
$VERSION = "0.1";
sub Version { $VERSION; }

use strict;

# ---------------------------------------------------------------------------

sub new {
  my $class = shift; $class = ref($class) || $class;
  my $self = { };
  bless ($self, $class);
  $self;
}

# ---------------------------------------------------------------------------
# implement these methods:

sub scoop_die {
  my ($self, @msg) = @_;
  die "unimplemented base class method";
}

sub scoop_warn {
  my ($self, @msg) = @_;
  die "unimplemented base class method";
}

sub dbg {
  my ($self, @msg) = @_;
  die "unimplemented base class method";
}

sub sitewarn {
  my ($self, $sitefilename, @msg) = @_;
  die "unimplemented base class method";
}

sub verbose {
  my ($self, @msg) = @_;
  die "unimplemented base class method";
}

sub cleanexit {
  my ($self, $exitcode) = @_;
  die "unimplemented base class method";
}

# ---------------------------------------------------------------------------

1;
