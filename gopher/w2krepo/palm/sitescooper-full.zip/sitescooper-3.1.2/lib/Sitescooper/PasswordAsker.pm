#===========================================================================

package Sitescooper::PasswordAsker;

require Exporter;
use Carp;

@ISA = qw(Exporter);
@EXPORT= qw();
$VERSION = "0.1";
sub Version { $VERSION; }

use strict;

sub new {
  my ($class, $scoop) = @_; $class = ref($class) || $class;
  my $self = { };
  $self->{scoop} = $scoop;
  bless ($self, $class);
  $self;
}

sub ask_user_for_credentials {
  croak "Sitescooper::PasswordAsker base class method called";
}

1;
