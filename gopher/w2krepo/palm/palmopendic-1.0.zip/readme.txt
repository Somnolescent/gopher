PalmOpenDic
===========

(c) 2008-2010 Michael Schierl

This program is Free Software according to the GNU General Public 
License, Version 2. You can find this license in the "COPYING" file.

Usage
-----

Sync PalmOpenDic.prc onto your Palm device. If you don't have it
already, sync SysZLib.prc as well. Copy at least one dictionary into
the /PALM/Programs/PalmOpenDic directory of your expansion card. You
can change this path in the options dialog if you do not like that
location.

If you don't have it already, sync SysZLib-68k.prc or SysZLib-arm.prc
onto your Palm device as well. Use the ARM version if you have a Palm
with PalmOS 5.0 or higher.

When started, you can enable Command Bar integration in the options
screen if you like. If you have Command Bar integration enabled and
want to remove this program later (hopefully not *g*), it is advisable
to disable command bar integration and perform a soft reset prior to
removal. Otherwise a small resource DB containing the command bar icon
might stay on your device after removal (It is called
"PalmOpenDic-Icon"; you can delete it with FileZ or a similar tool).

You can use PalmOpenDic with the Plucker Plugin Integration, by
choosing "Custom" and entering these settings:

Name: PalmOpenDic
[v] Clipboard   [_] DA
Command: CustomBase + 0

Known limitations
-----------------

In PalmOS 4, when Command Bar integration is enabled, Launcher may
crash. This happens if you perform a soft reset. After the soft reset,
without having invoked the command bar before, open the command bar in
Launcher and select the Beam or Categories command. This is a bug in
the Launcher application and also happens with other programs that add
icons to the command bar. To work around this problem, do this
whenever you performed a soft reset: Open any other application (for
example Memo Pad), invoke the command bar once (close it without
selecting anything), and return to the launcher. Now the bug will not
happen any more until you perform the next soft reset.

In fact, unless you really want to beam an application or adjust
categories after a soft reset, you will not run into that bug at
all. But if you do, you will retry after each soft reset and run into
it again and again.

Databases
---------

There is one database included:

empty.pdb: This database (with internal name "- Empty -" does not
           contain any records. Since PalmOpenDic loads the
           alphabetically first database automatically, adding this
           database can speed up PalmOpenDic's launch if the first
           database is large and you do not use the first database often.

Additional databases are available from the website or can be created
using the dicmaker utility. Run java -jar dicmaker.jar for details.

As a special service, a Windows .cmd file is available that converts
the dictionary downloadable from 

http://www1.dict.cc/translation_file_request.php

to a PalmOpenDic dictionary. It does not matter if you select the .zip
file or extract it first, it works in both cases. Users of non-Windows
operating systems can run

java -jar dicmaker.jar dictcc <filename>.txt dict.cc DictCC.pdb

Contact me
----------

The homepage of pzdbView is http://pzdbview.sourceforge.net/

You can contact me at schierlm@users.sourceforge.net

Changelog
---------

+++ 2010-04-17: Version 1.0 released +++

- No changes in the Palm application except version number and copyright
- Changes in the dicmaker utility:
  * Add feature to dump dictionary content as CSV
  * Add support for XDXF (rudimentary) and Ergane dictionary formats
  * Add support for the new dict.cc dictionary format
  * Bugfixes:
    + Fix parsing of the latest Beolingus dictionary
    + Fix the file type name in the dict.cc import GUI
    + fixed a NullPointerException when the last line of a CSV file
      is empty or a comment

+++ 2008-03-19: Version 1.0-rc1 released +++

- When a word is marked in the details view,  use it as a new search.
- Add new preferences:
  * "Use last language by default"
  * "Clear input on language change"
  * "Clear input on dictionary change"
- Scroll to top of list on refresh
- Rename "Database" to "Dictionary" in the user interface
- Fix bug that prevented refresh when using the on-screen keyboard
- Try harder to select same language when switching dictionaries
- Restore keyboard focus on edit field after closing the details window
- Fix a bug in the sort function that sorted punctuation like end-of-string

+++ 2008-01-05: Version 0.9 released +++

- First public release
