Dear Visual Basic 6.0 fan,

Did you know how compact VB6 in its core is?

It is < 5 MB compressed!

However it is still able to run and compile your projects as long as all ActiveX DLLs, OCXs and TLBs etc.
that you referenced within your project are installed and registered.

You can even run this "NanoVB6" version on BartPE or other windows live CDs!
(BTW: In runs quite well under Linux/Wine, too!!)


Contents of VB6-Portable.rar:

VB6.OLB
VB6EXT.OLB
DAO350.DLL
MRT7ENU.DLL
MSO97RT.DLL
MSPDB60.DLL
VB6IDE.DLL
VBA6.DLL
C2.EXE
LINK.EXE
VB6.EXE
VBAEXE6.LIB


And finally a registry file ("VB6.REG") which contains keys needed for licensing:

============================================================================
Windows Registry Editor Version 5.00

[HKEY_CLASSES_ROOT\Licenses\74872840-703A-11d1-A3AF-00A0C90F26FA]
@="mninuglgknogtgjnthmnggjgsmrmgniglish"

[HKEY_CLASSES_ROOT\Licenses\74872841-703A-11d1-A3AF-00A0C90F26FA]
@="klglsejeilmereglrfkleeheqkpkelgejgqf"
============================================================================
