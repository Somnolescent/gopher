# AutoSite-98
The new hot static site generator of the next millenium from Bulb Microcomputer Software Inc.
