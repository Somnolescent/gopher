# AutoSite-98
The new hot static site generator of the new millenium from Bulb Microcomputer Software Inc.
