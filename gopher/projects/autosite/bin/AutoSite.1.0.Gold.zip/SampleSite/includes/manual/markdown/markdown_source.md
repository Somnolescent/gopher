<!-- attrib template: manual -->
<!-- attrib title: Using Markdown in AutoSite -->
<!-- attrib description: For simpler sites, you might not even need to write your pages in HTML! AutoSite features a full CommonMark Markdown parser to make writing new pages even easier. -->
<!-- attrib chapter: building -->

[**Markdown**](https://daringfireball.net/projects/markdown/) is a markup language that's meant to be simple and readable no matter what. Even as plain text, Markdown looks as good as when it's parsed and formatted. HTML can be used inside Markdown documents for advanced functionality (AutoSite still requires the [attribute declarations]([#root#]manual/attributes/) in Markdown, for example).

AutoSite supports the semi-canonical [CommonMark](https://commonmark.org) implementation; any Markdown files (text files with the `.md` extension) in your `pages` folder will get built into proper HTML documents. If you're mostly writing plain text with some light formatting (say, for a personal blog), you can use Markdown to speed up the process and save yourself some serious typing.

<h2 id="creating-a-markdown-document"><a href="#creating-a-markdown-document">[#]</a> Creating a Markdown Document</h2>
To create a new Markdown document, in the Sitemap, right click on the folder you'd like to create the document in, hover the "New" submenu, and select "Markdown Page (.md)". Type the name of the file and double-click it to bring it into the Code Editor.

<figure>
    <img src="markdown-new.png" alt="Creating a new Markdown file">
    <figcaption>Creating a new Markdown file</figcaption>
</figure>

<h2 id="learning-markdown-syntax"><a href="#learning-markdown-syntax">[#]</a> Learning Markdown Syntax</h2>
If you're interested in using Markdown for your site's pages, thankfully, Markdown is remarkably simple to learn. [John Gruber's original Markdown description](https://daringfireball.net/projects/markdown/syntax) is simple, if not exhaustive, and CommonMark maintains [a spec](https://spec.commonmark.org), a [cheat sheet](https://commonmark.org/help/), and [a tutorial](https://commonmark.org/help/tutorial/).

In the spirit of this manual as a demonstration piece for AutoSite, this page in particular has been written as much as possible in Markdown; you can view the original page source [here](markdown_source.md).