import pituophis
pituophis.serve("127.0.0.1", 70, pub_dir='pub/', tls=False)  # typical Gopher port is 70
