<!-- attrib template: default -->
<!-- attrib title: &#91;#template#] -->
<!-- attrib code: yeah -->
<div class="warning card">
    <b>This is an Apricot setting attribute.</b> It <em>can</em> be defined with <code>&lt;!-- attrib template: ... --></code>. Its default value is <code>default</code>.
</div>

The template file AutoSite should use, without the `.html`.

**Example:**
<code>&lt;!-- attrib template: default --></code>

**Output:** (page using the `default.html` file in the Templates folder)