# AutoSite
![MIT License (see License section)](https://img.shields.io/badge/license-MIT-green) ![Latest Release](https://img.shields.io/github/v/release/dotcomboom/AutoSite-XL) ![Code Size](https://img.shields.io/github/languages/code-size/dotcomboom/AutoSite-XL) [![Build status](https://ci.appveyor.com/api/projects/status/hjac5asumu53g0kk?svg=true)](https://ci.appveyor.com/project/dotcomboom/autosite)

![Screenshot](https://github.com/dotcomboom/AutoSite/blob/master/AutoSite/screenshot.png?raw=true)
