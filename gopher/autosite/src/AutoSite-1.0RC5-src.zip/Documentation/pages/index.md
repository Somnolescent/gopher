<!-- attrib template: default -->
<!-- attrib title: Help Topics -->
<!--
Notes:
  - &#91; is [
  - &#93; is ]

<div class="card">
  <h4>Important</h4>
  <hr>
  <p>AutoSite uses <code>default.html</code> as your default template.</p>
</div>
-->
## Internal Attributes
- <a href="[#root#]attrib/root/index.html"><code><span>&#91;</span>#root#]</code></a>
- <a href="[#root#]attrib/path/index.html"><code><span>&#91;</span>#path#]</code></a>
- <a href="[#root#]attrib/template/index.html"><code><span>&#91;</span>#template#]</code></a>

<!--## AutoSite
 - <a href="[#root#]core/diy/index.html">How to roll your own AutoSite Core</a> -->
 