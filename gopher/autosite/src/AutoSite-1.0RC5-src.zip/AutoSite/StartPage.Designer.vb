﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StartPage
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StartPage))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NewSite = New System.Windows.Forms.LinkLabel()
        Me.Recent1 = New System.Windows.Forms.LinkLabel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Recent2 = New System.Windows.Forms.LinkLabel()
        Me.Recent3 = New System.Windows.Forms.LinkLabel()
        Me.Recent4 = New System.Windows.Forms.LinkLabel()
        Me.Recent5 = New System.Windows.Forms.LinkLabel()
        Me.OpenSite = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.R1 = New System.Windows.Forms.PictureBox()
        Me.R2 = New System.Windows.Forms.PictureBox()
        Me.R3 = New System.Windows.Forms.PictureBox()
        Me.R4 = New System.Windows.Forms.PictureBox()
        Me.R5 = New System.Windows.Forms.PictureBox()
        Me.RWarn = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Name = "Label1"
        '
        'NewSite
        '
        Me.NewSite.ActiveLinkColor = System.Drawing.Color.Gainsboro
        Me.NewSite.AutoEllipsis = True
        resources.ApplyResources(Me.NewSite, "NewSite")
        Me.NewSite.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.NewSite.ForeColor = System.Drawing.Color.Black
        Me.NewSite.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.NewSite.LinkColor = System.Drawing.Color.White
        Me.NewSite.Name = "NewSite"
        Me.NewSite.TabStop = True
        '
        'Recent1
        '
        Me.Recent1.ActiveLinkColor = System.Drawing.Color.Gainsboro
        Me.Recent1.AutoEllipsis = True
        resources.ApplyResources(Me.Recent1, "Recent1")
        Me.Recent1.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Recent1.ForeColor = System.Drawing.Color.Black
        Me.Recent1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.Recent1.LinkColor = System.Drawing.Color.White
        Me.Recent1.Name = "Recent1"
        Me.Recent1.TabStop = True
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Name = "Label2"
        '
        'Recent2
        '
        Me.Recent2.ActiveLinkColor = System.Drawing.Color.Gainsboro
        Me.Recent2.AutoEllipsis = True
        resources.ApplyResources(Me.Recent2, "Recent2")
        Me.Recent2.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Recent2.ForeColor = System.Drawing.Color.Black
        Me.Recent2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.Recent2.LinkColor = System.Drawing.Color.White
        Me.Recent2.Name = "Recent2"
        Me.Recent2.TabStop = True
        '
        'Recent3
        '
        Me.Recent3.ActiveLinkColor = System.Drawing.Color.Gainsboro
        Me.Recent3.AutoEllipsis = True
        resources.ApplyResources(Me.Recent3, "Recent3")
        Me.Recent3.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Recent3.ForeColor = System.Drawing.Color.Black
        Me.Recent3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.Recent3.LinkColor = System.Drawing.Color.White
        Me.Recent3.Name = "Recent3"
        Me.Recent3.TabStop = True
        '
        'Recent4
        '
        Me.Recent4.ActiveLinkColor = System.Drawing.Color.Gainsboro
        Me.Recent4.AutoEllipsis = True
        resources.ApplyResources(Me.Recent4, "Recent4")
        Me.Recent4.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Recent4.ForeColor = System.Drawing.Color.Black
        Me.Recent4.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.Recent4.LinkColor = System.Drawing.Color.White
        Me.Recent4.Name = "Recent4"
        Me.Recent4.TabStop = True
        '
        'Recent5
        '
        Me.Recent5.ActiveLinkColor = System.Drawing.Color.Gainsboro
        Me.Recent5.AutoEllipsis = True
        resources.ApplyResources(Me.Recent5, "Recent5")
        Me.Recent5.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Recent5.ForeColor = System.Drawing.Color.Black
        Me.Recent5.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.Recent5.LinkColor = System.Drawing.Color.White
        Me.Recent5.Name = "Recent5"
        Me.Recent5.TabStop = True
        '
        'OpenSite
        '
        Me.OpenSite.ActiveLinkColor = System.Drawing.Color.Gainsboro
        Me.OpenSite.AutoEllipsis = True
        resources.ApplyResources(Me.OpenSite, "OpenSite")
        Me.OpenSite.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.OpenSite.ForeColor = System.Drawing.Color.Black
        Me.OpenSite.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.OpenSite.LinkColor = System.Drawing.Color.White
        Me.OpenSite.Name = "OpenSite"
        Me.OpenSite.TabStop = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.PictureBox1.Image = Global.AutoSite.My.Resources.Resources.NewSite
        resources.ApplyResources(Me.PictureBox1, "PictureBox1")
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        resources.ApplyResources(Me.PictureBox2, "PictureBox2")
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.TabStop = False
        '
        'R1
        '
        Me.R1.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.R1.Image = Global.AutoSite.My.Resources.Resources.Web
        resources.ApplyResources(Me.R1, "R1")
        Me.R1.Name = "R1"
        Me.R1.TabStop = False
        '
        'R2
        '
        Me.R2.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.R2.Image = Global.AutoSite.My.Resources.Resources.Web
        resources.ApplyResources(Me.R2, "R2")
        Me.R2.Name = "R2"
        Me.R2.TabStop = False
        '
        'R3
        '
        Me.R3.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.R3.Image = Global.AutoSite.My.Resources.Resources.Web
        resources.ApplyResources(Me.R3, "R3")
        Me.R3.Name = "R3"
        Me.R3.TabStop = False
        '
        'R4
        '
        Me.R4.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.R4.Image = Global.AutoSite.My.Resources.Resources.Web
        resources.ApplyResources(Me.R4, "R4")
        Me.R4.Name = "R4"
        Me.R4.TabStop = False
        '
        'R5
        '
        Me.R5.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.R5.Image = Global.AutoSite.My.Resources.Resources.Web
        resources.ApplyResources(Me.R5, "R5")
        Me.R5.Name = "R5"
        Me.R5.TabStop = False
        '
        'RWarn
        '
        Me.RWarn.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.RWarn.ForeColor = System.Drawing.Color.White
        resources.ApplyResources(Me.RWarn, "RWarn")
        Me.RWarn.Name = "RWarn"
        '
        'StartPage
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Controls.Add(Me.R5)
        Me.Controls.Add(Me.R4)
        Me.Controls.Add(Me.R3)
        Me.Controls.Add(Me.R2)
        Me.Controls.Add(Me.R1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.OpenSite)
        Me.Controls.Add(Me.Recent5)
        Me.Controls.Add(Me.Recent4)
        Me.Controls.Add(Me.Recent3)
        Me.Controls.Add(Me.Recent2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Recent1)
        Me.Controls.Add(Me.NewSite)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RWarn)
        Me.Name = "StartPage"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NewSite As System.Windows.Forms.LinkLabel
    Friend WithEvents Recent1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Recent2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Recent3 As System.Windows.Forms.LinkLabel
    Friend WithEvents Recent4 As System.Windows.Forms.LinkLabel
    Friend WithEvents Recent5 As System.Windows.Forms.LinkLabel
    Friend WithEvents OpenSite As LinkLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents R1 As PictureBox
    Friend WithEvents R2 As PictureBox
    Friend WithEvents R3 As PictureBox
    Friend WithEvents R4 As PictureBox
    Friend WithEvents R5 As PictureBox
    Friend WithEvents RWarn As Label
End Class
